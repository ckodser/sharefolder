#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/unistd.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Keivan Rezaei");
MODULE_DESCRIPTION("Hooking syscalls [open]");

void** sys_call_table_ptr;

asmlinkage int (*original_open)( const char __user *, int , mode_t);

asmlinkage int new_open( const char __user * pathname, int flags, mode_t mode ){
	printk(KERN_INFO "new system call is being used\n");
	return ( *original_open )( pathname, flags, mode );
}

int __init hook_open_syscall(void){
	printk(KERN_INFO "Starting hooking open syscall ....\n");

	write_cr0(read_cr0() & (~0x10000));
	
	sys_call_table_ptr = (void*) kallsyms_lookup_name("sys_call_table");
	
	original_open = sys_call_table_ptr[__NR_openat];
	
	sys_call_table_ptr[__NR_openat] = new_open;
	
	write_cr0(read_cr0() | (0x10000));
	
	return 0;
}

void __exit revert_open_syscall(void){
	write_cr0(read_cr0() & (~0x10000));
	sys_call_table_ptr[__NR_openat] = original_open;
	write_cr0(read_cr0() | (0x10000));
	printk(KERN_INFO "Hook is finished.\n");
}

module_init(hook_open_syscall);
module_exit(revert_open_syscall);

